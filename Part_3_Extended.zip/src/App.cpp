#include "App.h"
#include "SeaPlusPlusEngine.h"
#include "SeaPlusPlusInfoSupplier.h"
#include "Bag.h"
#include "BagChecker.h"

#include <iostream>
#include <string>
#include <sstream>
#include <limits>
#include <map>
#include <set>
#include <algorithm>
#include <cctype>

std::string normalize(const std::string& input) {
    std::string result;
    for (char ch : input) {
        if (!std::isspace(ch)) result += std::tolower(ch);
    }
    return result;
}

std::string simplifyName(const std::string& s) {
    std::string result;
    for (char ch : s) {
        if (std::isalnum(ch)) result += std::tolower(ch);
    }
    return result;
}

std::string trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t");
    size_t last = str.find_last_not_of(" \t");
    return (first == std::string::npos) ? "" : str.substr(first, last - first + 1);
}

std::map<std::string, int> getGroupLimits() {
    return {
        {"Tuna", 5}, {"Flathead", 10}, {"DeepSeaFish", 5},
        {"SharksAndRays", 5}, {"SamsonAmberjack", 5}, {"Mullet", 20},
        {"Mackerel", 5}, {"Bream&Tarwhine", 10}, {"AustralianBass&EstuaryPerch", 2},
        {"Marlin", 1}
    };
}

void App::run() {
    SeaPlusPlusEngine engine;

    while (true) {
        std::vector<SeaCreature*> regulations = SeaPlusPlusInfoSupplier::loadSeaCreaturesFromCSV(
            "C:\\Software Assignments\\Assignment 2\\SeaPlusPlus\\data\\SeaPlusPlus_Regulations.csv"
        );

        Bag userBag;
        BagChecker bagChecker;
        std::string hasBag;

        std::cout << "\nWELCOME TO SeaPlusPlus!\nThis software helps Aussie fishers ensure their caught fish are valid to keep based on current regulations.\n"
                     "Please enter correct Fish Names from the catalogue for accurate results.\n\n"
                     "Important: You can enter multiple fish if you have a bag to keep them. (Type 'Yes')\n"
                     "Otherwise, type 'No' to check a single fish individually.\n\n"
                     "Do you have a Bag to keep fish? (Yes/No): ";
        std::getline(std::cin, hasBag);

        if (normalize(hasBag) == "yes") {
            std::string fishList;
            std::cout << "Enter the fish you caught and their quantities (e.g., Wahoo: 3, Octopus: 4): ";
            std::getline(std::cin, fishList);

            std::stringstream ss(fishList);
            std::string token;
            std::map<std::string, int> fishMap;

            while (std::getline(ss, token, ',')) {
                size_t colon = token.find(':');
                if (colon != std::string::npos) {
                    std::string name = trim(token.substr(0, colon));
                    int count = std::stoi(trim(token.substr(colon + 1)));
                    fishMap[name] = count;
                }
            }

            std::map<std::string, int> groupCounts;
            auto groupLimits = getGroupLimits();

            // Count group totals
            for (const auto& entry : fishMap) {
                for (SeaCreature* c : regulations) {
                    if (simplifyName(c->getName()) == simplifyName(entry.first)) {
                        groupCounts[c->getGroupName()] += entry.second;
                        break;
                    }
                }
            }

            bool groupViolation = false;
            std::set<std::string> violatedGroups;

            // Detect group violations
            for (const auto& group : groupCounts) {
                auto it = groupLimits.find(group.first);
                if (it != groupLimits.end() && group.second > it->second) {
                    std::cout << "\nGroup violation! " << group.first << " group can have only "
                              << it->second << " in total. You tried to enter " << group.second << ". \nPLEASE TRY TO REDUCE THE NUMBER OF FISH AND TRY AGAIN!.\n";
                    groupViolation = true;
                    violatedGroups.insert(group.first);
                }
            }

            // Process only non-violating fish
            for (const auto& entry : fishMap) {
                std::string inputName = entry.first;
                int quantity = entry.second;

                SeaCreature* matched = nullptr;
                for (SeaCreature* c : regulations) {
                    if (simplifyName(c->getName()) == simplifyName(inputName)) {
                        matched = c;
                        break;
                    }
                }

                if (!matched) {
                    std::cout << "Sorry! We Cannot find a fish named " << inputName << " in the database.\n";
                    continue;
                }

                if (violatedGroups.count(matched->getGroupName())) {
                    std::cout << "\nSkipping " << matched->getName()
                              << " because its group exceeds the allowed limit.\n";
                    continue;
                }

                if (quantity > matched->getBagLimit()) {
                    std::cout << "\nSorry! You can only have " << matched->getBagLimit() << " of "
                              << matched->getName() << ". You entered " << quantity << ". Skipping this fish.\n\n";
                    continue;
                }

                for (int i = 1; i <= quantity; ++i) {
                    std::cout << "\n[" << matched->getName() << " #" << i << "] Enter size (cm): ";
                    float size;
                    std::cin >> size;
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

                    std::string eggInput;
                    std::cout << "Is it carrying eggs? (yes/no): ";
                    std::getline(std::cin, eggInput);
                    bool isCarryingEggs = (normalize(eggInput) == "yes");

                    SeaCreature* validated = engine.createCreature(
                        matched->getType(), matched->getName(), size, matched->getGroupName(), isCarryingEggs,
                        matched->getMinLength(), matched->getMaxLength(),
                        matched->getBagLimit(), matched->getNotes(), matched->getCarriesEggRule()
                    );

                    if (engine.validateCreature(*validated)) {
                        userBag.addCreature(*validated);
                        std::cout << "Congrats! This fish can be added to your bag!\n";
                    } else {
                        std::cout << "Sorry! This fish cannot be added to your bag!\n";
                        std::cout << engine.reportViolation() << "\n";
                    }

                    if (!validated->getNotes().empty()) {
                        std::cout << "Note: " << validated->getNotes() << "\n";
                    }

                    delete validated;
                }
            }

            // Show final bag result
            if (userBag.getAllCreatures().empty()) {
                std::cout << "\n!! Your bag should be empty. No valid fish added.!!\n\n";
            } else {
                std::string groupError;
                std::cout << "\nYou can keep " << userBag.getAllCreatures().size()
                          << " valid catch(es) in your bag!\n";

                if (bagChecker.validateBag(userBag, groupError)) {
                    std::cout << " Final allowed catches: " << userBag.getAllCreatures().size() << "\n\n";
                } else {
                    std::cout << " Group bag rule violated: " << groupError << "\n\n";
                }
            }

        } else {
            // Single fish checking
            std::string userInput;
            std::cout << "\nEnter the single fish name you want to check (or type 'exit'): ";
            std::getline(std::cin, userInput);
            if (normalize(userInput) == "exit") break;

            SeaCreature* matched = nullptr;
            for (SeaCreature* c : regulations) {
                if (simplifyName(c->getName()) == simplifyName(userInput)) {
                    matched = c;
                    break;
                }
            }

            if (!matched) {
                std::cout << "Sorry, We cannot find this fish in our regulations.\n";
                continue;
            }

            float size;
            std::cout << "Enter the size (cm): ";
            std::cin >> size;
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            std::string eggInput;
            std::cout << "Is it carrying eggs? (yes/no): ";
            std::getline(std::cin, eggInput);
            bool isCarryingEggs = (normalize(eggInput) == "yes");

            SeaCreature* validated = engine.createCreature(
                matched->getType(), matched->getName(), size, matched->getGroupName(), isCarryingEggs,
                matched->getMinLength(), matched->getMaxLength(),
                matched->getBagLimit(), matched->getNotes(), matched->getCarriesEggRule()
            );

            if (engine.validateCreature(*validated)) {
                std::cout << " You can keep this catch!\n";
            } else {
                std::cout << " " << engine.reportViolation() << "\n";
            }

            if (!validated->getNotes().empty()) {
                std::cout << "Note: " << validated->getNotes() << "\n";
            }

            delete validated;
        }

        std::string prompt;
        std::cout << "\nThank you for using SeaPlusPlus!\nPress Enter to continue or type 'Exit' to quit: ";
        std::getline(std::cin, prompt);

        for (SeaCreature* c : regulations) delete c;
        if (normalize(prompt) == "exit") {
            std::cout << " Program terminated. Have a great day!\n";
            break;
        }
    }
}
