#include "InvertebrateCreature.h"

/**
 * Constructs an InvertebrateCreature object using detailed regulatory attributes.
 * This object is passed through validation routines and used for rule enforcement.
 */

InvertebrateCreature::InvertebrateCreature(std::string name, float size, std::string groupName, std::string type,
                                           bool isCarryingEggs, float minLength, float maxLength,
                                           int bagLimit, std::string notes, bool carriesEggRule)
        : SeaCreature(name, size, groupName, type, isCarryingEggs, minLength, maxLength, bagLimit, notes, carriesEggRule) {
    // No extra logic for now
}
