#include "SeaPlusPlusInfoSupplier.h"
#include "VertebrateCreature.h"
#include "InvertebrateCreature.h"

#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>

// Reads data from a CSV and creates SeaCreature instances

// Loads SeaCreature objects from a CSV file.
std::vector<SeaCreature*> SeaPlusPlusInfoSupplier::loadSeaCreaturesFromCSV(const std::string& filename) {
    std::vector<SeaCreature*> creatures;
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << " Error: Could not open file " << filename << std::endl;
        return creatures;
    }

    std::string line;
    std::getline(file, line); // Skip header row

    while (std::getline(file, line)) {
        std::vector<std::string> fields;
        std::stringstream ss(line);
        std::string field;
        bool inQuotes = false;
        std::string current;

        // Parse each CSV line properly (handle quoted commas)
        while (std::getline(ss, field, ',')) {
            if (!inQuotes) {
                if (!field.empty() && field.front() == '"') {
                    inQuotes = true;
                    current = field;
                } else {
                    fields.push_back(field);
                }
            } else {
                current += "," + field;
                if (!field.empty() && field.back() == '"') {
                    inQuotes = false;
                    fields.push_back(current);
                }
            }
        }

        if (fields.size() != 10) {
            std::cerr << " Invalid data in row (skipping): " << line << std::endl;
            continue;
        }

        // Remove quotes from each field
        for (std::string& f : fields) {
            if (!f.empty() && f.front() == '"') f.erase(0, 1);
            if (!f.empty() && f.back() == '"') f.pop_back();
        }

        // Extract each attribute from the CSV row

        std::string name        = fields[0];
        std::string shortName   = fields[1];
        std::string group       = fields[2];
        std::string type        = fields[3];
        std::string minStr      = fields[4];
        std::string maxStr      = fields[5];
        std::string bagLimitStr = fields[6];
        std::string possession  = fields[7];
        std::string notes       = fields[8];
        std::string eggsStr     = fields[9];

        float minLength = 0.0f, maxLength = 0.0f;
        int bagLimit = 0;
        bool isCarryingEggs = false;
        bool carriesEggRule = false;

        try {
            if (!minStr.empty()) minLength = std::stof(minStr);
            if (!maxStr.empty()) maxLength = std::stof(maxStr);
            if (!bagLimitStr.empty()) bagLimit = std::stoi(bagLimitStr);
            isCarryingEggs = (eggsStr == "true" || eggsStr == "TRUE" || eggsStr == "True");
            carriesEggRule = (eggsStr == "true" || eggsStr == "TRUE" || eggsStr == "True");
        } catch (const std::exception& e) {
            std::cerr << " Conversion error in row (skipping): " << line << std::endl;
            continue;
        }

        // Instantiate correct type

        SeaCreature* creature = nullptr;
        if (isVertebrate(type)) {
            creature = new VertebrateCreature(name, 0.0f, group, type, isCarryingEggs,
                                              minLength, maxLength, bagLimit, notes, carriesEggRule);
        } else {
            creature = new InvertebrateCreature(name, 0.0f, group, type, isCarryingEggs,
                                                minLength, maxLength, bagLimit, notes, carriesEggRule);
        }

        creatures.push_back(creature);
    }

    file.close();
    return creatures;
}

// Determines if the creature type is Vertebrate
bool SeaPlusPlusInfoSupplier::isVertebrate(const std::string& groupType) {
    return groupType == "Vertebrate";
}
