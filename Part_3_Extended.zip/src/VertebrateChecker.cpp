#include "VertebrateChecker.h"

bool VertebrateChecker::validateCreature(const SeaCreature& creature) {
    // First check size limits
    if (!creature.isWithinSizeLimits()) {
        violationMessage = "This Vertebrate size is not within legal limits. You Cannot keep the catch!";
        return false;
    }

    // Optionally check for egg rules (depends on group)
    if (!creature.isAllowedToKeep()) {
        violationMessage = "Creature is carrying eggs and must be released.";
        return false;
    }

    return true; // Passed all checks
}

std::string VertebrateChecker::reportViolation() const {
    return violationMessage;
}
