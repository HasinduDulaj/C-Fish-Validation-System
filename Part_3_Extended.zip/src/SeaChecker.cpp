// SeaChecker.cpp
#include "SeaChecker.h"
// This file might remain empty unless shared logic for all checkers is needed.

