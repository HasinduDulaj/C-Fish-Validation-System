// BagChecker.cpp
#include "BagChecker.h"
#include <unordered_map>

//  This method now only validates per-species bag limits (group limit moved to App.cpp)
bool BagChecker::validateBag(const Bag& bag, std::string& errorMessage) {
    auto creatures = bag.getAllCreatures();
    std::unordered_map<std::string, int> nameCountMap;

    for (const auto& creature : creatures) {
        std::string name = creature.getName();

        //  Skip if the species has no bag limit (0)
        if (creature.getBagLimit() == 0) continue;

        nameCountMap[name]++;
        if (nameCountMap[name] > creature.getBagLimit()) {
            errorMessage = "Bag limit exceeded for species: " + name + " (Max: " + std::to_string(creature.getBagLimit()) + ")";
            return false;
        }
    }

    return true; //  All species passed their individual bag limits
}
