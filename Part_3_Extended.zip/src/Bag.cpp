#include "Bag.h"

// Add a new creature to the bag
void Bag::addCreature(const SeaCreature& creature) {
    creatures.push_back(creature);
}

// Return the full list of caught creatures
std::vector<SeaCreature> Bag::getAllCreatures() const {
    return creatures;
}

// Count how many of a specific named creature are in the bag
int Bag::countByName(const std::string& name) const {
    int count = 0;
    for (const auto& c : creatures) {
        if (c.getName() == name) {
            count++;
        }
    }
    return count;
}

// Count how many creatures are in a specific group (e.g., all crabs or lobsters)
int Bag::countByGroup(const std::string& groupName) const {
    int count = 0;
    for (const auto& c : creatures) {
        if (c.getGroupName() == groupName) {
            count++;
        }
    }
    return count;
}

