#include "SeaPlusPlusEngine.h"

// Constructor that registers available checkers
SeaPlusPlusEngine::SeaPlusPlusEngine() {
    checkers.push_back(std::make_shared<VertebrateChecker>());
    checkers.push_back(std::make_shared<InvertebrateChecker>());
}

// Validates a SeaCreature using registered checkers
bool SeaPlusPlusEngine::validateCreature(const SeaCreature& creature) {
    violations.clear();
    bool isValid = true;

    for (const auto& checker : checkers) {
        if (checker->validateCreature(creature)) {
            continue;
        } else {
            isValid = false;
            violations.push_back(checker->reportViolation());
        }
    }

    return isValid;
}

// Returns all recorded violations
std::vector<std::string> SeaPlusPlusEngine::getViolations() const {
    return violations;
}

std::string SeaPlusPlusEngine::reportViolation() const {
    if (!violations.empty()) {
        return violations.back();  // Return last violation for single output
    }
    return "";
}

// Dynamically creates a SeaCreature instance
SeaCreature* SeaPlusPlusEngine::createCreature(
    const std::string& type,
    const std::string& name,
    float size,
    const std::string& group,
    bool isCarryingEggs,
    float minLength,
    float maxLength,
    int bagLimit,
    const std::string& notes,
    bool carriesEggRule
) {
    if (type == "Vertebrate") {
        return new VertebrateCreature(name, size, group, type, isCarryingEggs, minLength, maxLength, bagLimit, notes, carriesEggRule);
    } else {
        return new InvertebrateCreature(name, size, group, type, isCarryingEggs, minLength, maxLength, bagLimit, notes, carriesEggRule);
    }
}
