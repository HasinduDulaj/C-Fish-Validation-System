#include "SeaCreature.h"
#include <ctime>

/**
 * Constructor for SeaCreature
 */

SeaCreature::SeaCreature(std::string name, float size, std::string groupName, std::string type, bool isCarryingEggs,
                         float minLength, float maxLength, int bagLimit, std::string notes, bool carriesEggRule)
        : name(name), size(size), groupName(groupName), type(type), isCarryingEggs(isCarryingEggs),
          minLength(minLength), maxLength(maxLength), bagLimit(bagLimit),
          notes(notes), carriesEggRule(carriesEggRule) {}

/**
 * Checks whether the size of the sea creature is within legal bounds.
 * Returns true if there is no specific size rule, or if the size falls within min/max range.
 */

bool SeaCreature::isWithinSizeLimits() const {
    if (notes.find("no length rule") != std::string::npos || (minLength == 0 && maxLength == 0)) {
        return true;
    }

    // Compare using float precision
    return size >= minLength && (maxLength == 0 || size <= maxLength);
}

/**
 * Evaluates general conditions to determine if the sea creature is allowed to be kept.
 * Includes seasonal and note-based conditions.
 */

bool SeaCreature::isAllowedToKeep() const {
    if (notes.find("release only") != std::string::npos ||
        notes.find("must be released immediately") != std::string::npos ||
        notes.find("protected") != std::string::npos ||
        notes.find("for bait only") != std::string::npos ||
        notes.find("bait only") != std::string::npos) {
        return false;
    }

    if (notes.find("closed season") != std::string::npos) {
        int currentMonth = std::localtime(nullptr)->tm_mon + 1;
        if (currentMonth >= 5 && currentMonth <= 8) {
            return false;
        }
    }

    return isWithinSizeLimits();
}

// === Getters ===

float SeaCreature::getMinLength() const { return minLength; }
float SeaCreature::getMaxLength() const { return maxLength; }
std::string SeaCreature::getName() const { return name; }
std::string SeaCreature::getGroupName() const { return groupName; }
std::string SeaCreature::getType() const { return type; }
bool SeaCreature::getIsCarryingEggs() const { return isCarryingEggs; }
int SeaCreature::getBagLimit() const { return bagLimit; }
std::string SeaCreature::getNotes() const { return notes; }
bool SeaCreature::requiresEggRule() const { return carriesEggRule; }
bool SeaCreature::getCarriesEggRule() const { return carriesEggRule; }
