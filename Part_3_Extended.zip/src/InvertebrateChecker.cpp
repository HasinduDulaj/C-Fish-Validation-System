#include "InvertebrateChecker.h"

/**
 * Validates an invertebrate creature using egg-carrying and size rules.
 * If the creature violates any rule, a message is stored and false is returned.
 */

bool InvertebrateChecker::validateCreature(const SeaCreature& creature) {
    // ✅ Only apply egg-carrying rule if carriesEggRule is true
    if (creature.getIsCarryingEggs() && creature.getCarriesEggRule()) {
        violationMessage = "Invertebrate is carrying eggs and must be released.";
        return false;
    }

    // ✅ Check size
    if (!creature.isWithinSizeLimits()) {
        violationMessage = "This Invertebrate's Size is outside allowed range. You should release the catch.";
        return false;
    }

    return true;
}

/**
 * Returns the most recent validation failure message.
 * Called by higher-level classes to report issues to the user.
 */

std::string InvertebrateChecker::reportViolation() const {
    return violationMessage;
}
