#include "VertebrateCreature.h"

// Pass all values directly to the base SeaCreature constructor
VertebrateCreature::VertebrateCreature(std::string name, float size, std::string groupName, std::string type,
                                       bool isCarryingEggs, float minLength, float maxLength,
                                       int bagLimit, std::string notes, bool carriesEggRule)
        : SeaCreature(name, size, groupName, type, isCarryingEggs, minLength, maxLength, bagLimit, notes, carriesEggRule) {

}
