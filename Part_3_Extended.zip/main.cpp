#include "App.h"

int main() {
    App app;
    app.run();  // ✅ Launches the CLI fishing rule checker
    return 0;
}
