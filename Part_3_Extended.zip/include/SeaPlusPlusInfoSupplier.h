#ifndef SEAPLUSPLUS_SEAPLUSPLUSINFOSUPPLIER_H
#define SEAPLUSPLUS_SEAPLUSPLUSINFOSUPPLIER_H

#include <vector>
#include <string>
#include "SeaCreature.h"

// Forward declarations
class SeaCreature;

// Helper class to read sea creature data from CSV and identify types
class SeaPlusPlusInfoSupplier {
public:
    // Load sea creature regulations from a CSV file and return them as SeaCreature objects
    static std::vector<SeaCreature*> loadSeaCreaturesFromCSV(const std::string& filename);

    // Helper to determine if a group is vertebrate
    static bool isVertebrate(const std::string& groupName);
};

#endif // SEAPLUSPLUS_SEAPLUSPLUSINFOSUPPLIER_H
