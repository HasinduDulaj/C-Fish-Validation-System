#ifndef SEAPLUSPLUS_INVERTEBRATECHECKER_H
#define SEAPLUSPLUS_INVERTEBRATECHECKER_H

#include "SeaChecker.h"

/**
 * InvertebrateChecker is responsible for validating rules specific to invertebrate sea creatures.
 * It inherits from the abstract base class SeaChecker and implements rule checking logic
 * such as size limits and egg-carrying constraints.
 */

class InvertebrateChecker : public SeaChecker {
private:
    std::string violationMessage;   // Stores the specific validation failure message

public:
    // Validates a given invertebrate creature and stores any rule violation message
    bool validateCreature(const SeaCreature& creature) override;

    // Returns the last stored rule violation message
    std::string reportViolation() const override;
};

#endif // SEAPLUSPLUS_INVERTEBRATECHECKER_H
