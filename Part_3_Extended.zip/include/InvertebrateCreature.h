#ifndef INVERTEBRATECREATURE_H
#define INVERTEBRATECREATURE_H

#include "SeaCreature.h"

/**
 * InvertebrateCreature represents sea creatures that are invertebrates (e.g., squid, crab).
 * This class extends SeaCreature and serves as a concrete data model used during validation.
 * It is constructed with full details required for regulatory validation.
 */

class InvertebrateCreature : public SeaCreature {
public:
    // Constructor to initialize all properties of an invertebrate sea creature
    InvertebrateCreature(std::string name, float size, std::string groupName, std::string type, bool isCarryingEggs,
                         float minLength, float maxLength, int bagLimit,
                         std::string notes, bool carriesEggRule);
};

#endif
