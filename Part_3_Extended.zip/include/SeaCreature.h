#ifndef SEAPLUSPLUS_SEACREATURE_H
#define SEAPLUSPLUS_SEACREATURE_H

#include <string>

/**
 * Base class representing any type of sea creature.
 * Contains attributes and behavior common to both vertebrates and invertebrates.
 */

class SeaCreature {
protected:
    std::string name;
    float size;
    std::string groupName;
    std::string type;             // Vertebrate or Invertebrate
    bool isCarryingEggs;
    float minLength;
    float maxLength;
    int bagLimit;
    std::string notes;            //  Notes field (optional rules, comments)
    bool carriesEggRule;          //  Determines if egg rule applies

public:
    //  Constructor with 'type' and 'carriesEggRule'
    SeaCreature(std::string name, float size, std::string groupName, std::string type,
                bool isCarryingEggs, float minLength, float maxLength,
                int bagLimit, std::string notes, bool carriesEggRule);

    //  Core validation functions
    bool isWithinSizeLimits() const;
    bool isAllowedToKeep() const;

    //  Getters
    std::string getName() const;
    std::string getGroupName() const;
    std::string getType() const;
    bool getIsCarryingEggs() const;
    float getMinLength() const;
    float getMaxLength() const;
    int getBagLimit() const;
    std::string getNotes() const;
    bool getCarriesEggRule() const;
    bool requiresEggRule() const;

};

#endif // SEACREATURE_H

