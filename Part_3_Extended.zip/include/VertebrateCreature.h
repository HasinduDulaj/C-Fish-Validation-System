#ifndef VERTEBRATECREATURE_H
#define VERTEBRATECREATURE_H

#include "SeaCreature.h"

/**
 * A concrete implementation of SeaCreature representing vertebrates.
 * Inherits all behavior from SeaCreature, no additional logic is added here.
 */

class VertebrateCreature : public SeaCreature {
public:
    VertebrateCreature(std::string name, float size, std::string groupName, std::string type, bool isCarryingEggs,
                       float minLength, float maxLength, int bagLimit,
                       std::string notes, bool carriesEggRule);
};

#endif
