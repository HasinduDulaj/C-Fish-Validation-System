#ifndef SEAPLUSPLUS_BAGCHECKER_H
#define SEAPLUSPLUS_BAGCHECKER_H

#include "Bag.h"
#include <string>

class BagChecker {
public:
    // Validates the contents of a bag
    bool validateBag(const Bag& bag, std::string& errorMessage);
};

#endif // SEAPLUSPLUS_BAGCHECKER_H
