#ifndef APP_H
#define APP_H

#include <vector>
#include "SeaCreature.h"

class App {
public:
    void run();  // Main method to run the app
};

#endif // APP_H
