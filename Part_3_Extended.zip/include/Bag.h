#ifndef SEAPLUSPLUS_BAG_H
#define SEAPLUSPLUS_BAG_H

#include "SeaCreature.h"
#include <vector>
#include <string>

class Bag {
private:
    std::vector<SeaCreature> creatures;  // All fish caught by the angler

public:
    void addCreature(const SeaCreature& creature);           // Add a new catch
    std::vector<SeaCreature> getAllCreatures() const;        // Get the full list
    int countByName(const std::string& name) const;          // Count fish by exact name
    int countByGroup(const std::string& groupName) const;    // Count fish by group
};

#endif // SEAPLUSPLUS_BAG_H

