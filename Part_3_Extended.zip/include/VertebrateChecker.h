#ifndef SEAPLUSPLUS_VERTEBRATECHECKER_H
#define SEAPLUSPLUS_VERTEBRATECHECKER_H

#include "SeaChecker.h"

/**
 * VertebrateChecker is responsible for validating vertebrate sea creatures.
 * It checks size constraints and egg-carrying rules as required.
 */

class VertebrateChecker : public SeaChecker {
private:
    std::string violationMessage;  // Stores validation error message (if any)

public:
    bool validateCreature(const SeaCreature& creature) override; // Runs validation
    std::string reportViolation() const override; // Returns violation message
};

#endif // SEAPLUSPLUS_VERTEBRATECHECKER_H