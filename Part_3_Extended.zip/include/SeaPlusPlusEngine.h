#ifndef SEAPLUSPLUSENGINE_H
#define SEAPLUSPLUSENGINE_H

#include "SeaCreature.h"
#include "SeaChecker.h"
#include "VertebrateChecker.h"
#include "InvertebrateChecker.h"
#include "VertebrateCreature.h"
#include "InvertebrateCreature.h"

#include <vector>
#include <string>
#include <memory>

// Mediator class that handles validation through SeaChecker implementations
class SeaPlusPlusEngine {
private:
    std::vector<std::shared_ptr<SeaChecker>> checkers; // Registered checkers
    std::vector<std::string> violations; // Collected violations

public:
    SeaPlusPlusEngine();  // Constructor to initialize checkers

    // Uses checkers to validate a creature and collect violations
    bool validateCreature(const SeaCreature& creature);

    // Returns collected violation messages
    std::vector<std::string> getViolations() const;

    // Returns the last violation only (for single output in App.cpp)
    std::string reportViolation() const;

    // Factory method for creating a SeaCreature object dynamically
    SeaCreature* createCreature(
        const std::string& type,
        const std::string& name,
        float size,
        const std::string& group,
        bool isCarryingEggs,
        float minLength,
        float maxLength,
        int bagLimit,
        const std::string& notes,
        bool carriesEggRule
    );
};

#endif // SEAPLUSPLUSENGINE_H
