// SeaChecker.h
#ifndef SEAPLUSPLUS_SEACHECKER_H
#define SEAPLUSPLUS_SEACHECKER_H

#include "SeaCreature.h"
#include <string>

/**
 * Abstract base class for sea creature validation checkers.
 * Defines the interface for type-specific rule checking (e.g., for vertebrates/invertebrates).
 */

class SeaChecker {
public:
    // Validates a sea creature based on specific rules
    virtual bool validateCreature(const SeaCreature& creature) = 0;

    // Returns the reason if the creature is not valid
    virtual std::string reportViolation() const = 0;

    // Virtual destructor for safe cleanup
    virtual ~SeaChecker() = default;
};

#endif // SEAPLUSPLUS_SEACHECKER_H
